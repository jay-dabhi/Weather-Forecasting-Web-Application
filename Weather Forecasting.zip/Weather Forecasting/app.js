const express = require("express");
const https = require("https");
const bodyParser = require("body-parser");


const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("static"));


app.get("/", function (req, res) {

    res.sendFile(__dirname + "/index.html");
});

app.post("/", function (req, res) {

    console.log("Post Request Recived");
    const query = req.body.CityName;
    const unit = req.body.Tempeture;
    const APIkey = "901ffadf5ea5e1c6fa62f45aed7fc135";

    // console.log(query);
    // console.log(unit);

    const url = "https://api.openweathermap.org/data/2.5/weather?appid=" + APIkey + "&q=" + query + "&units=" + unit + "";
    https.get(url, function (response) {

        console.log(response.statusCode);
        response.on('data', function (data) {

            const WeatherData = JSON.parse(data)

            const tempature = WeatherData.main.temp
            const Discription = WeatherData.weather[0].description
            const image = WeatherData.weather[0].icon
            const Humidity = WeatherData.main.humidity
            const temp_min = WeatherData.main.temp_min
            const temp_max = WeatherData.main.temp_max
            const pressure = WeatherData.main.pressure
            const WindSpeed = WeatherData.wind.speed
            const visiblity = WeatherData.visibility
            const Cor_Long = WeatherData.coord.lon
            const Cor_Lang = WeatherData.coord.lat



            // html code for response page
            const head_style = "'width: 100%;height:7.5%; margin-top:2%;background-color: #A7727D;text-align: center;color: #F9F5E7 ;border-radius: 5px;'";
            const body_style = "'background-color: #F9F5E7;font-size: x-large;'";
            const container_main_style = "'background-color: #F9F5E7;height: 90%;width: 100%;display: flex;align-items: center;justify-content: center;'";
            const container_inner_style = "'height: 20em;width: 20em;background-color: #EDDBC7;margin-top: 5% ;text-align: center;border-radius: 5px;'";


            const H1_Inner = "Walcome to Weather App";
            const inner_div_html = "<div class='container-inner' style=" + container_inner_style + "></div></div>";
            const outer_div_html = "<div class='container-main' style=" + container_main_style + ">";
            const ul_html = "<ul style='list-style: none; color:#A7727D'><li>City Name: " + query + "</li><li>longitudes: " + Cor_Long + " </li><li>Latitudes:" + Cor_Lang + "</li><li>" + "<img src=" + "http://openweathermap.org/img/wn/" + image + "@2x.png" + "> " + "</li><li>Tempature: " + tempature + "</li><li>Min_Tempature: " + temp_min + "</li><li>Max_Tempature: " + temp_max + "</li><li>Weather Discritpion: " + Discription + "</li><li>Humidity: " + Humidity + "</li><li>Pressure: " + pressure + "</li><li>Visiblity: " + visiblity + "</li><li>WindSpeed: " + WindSpeed + "</li></ul>"

            res.write("<body style=" + body_style  + "></body>");

            res.write("<div class='head' style="+ head_style +"><h1>" + H1_Inner + "</h1></div>");

            res.write("<div class='container-main' style=" + container_main_style + ">" + "<div class='container-inner' style=" + container_inner_style + ">" + ul_html + "</div></div>" );

            // res.write("<p style='font-size:100px ;'>Weather Discription :" + Discription + "</p><br>");
            // res.write("<h1>Tempature is " + tempature + "</h1>");


            // res.write("<img src=" + "http://openweathermap.org/img/wn/" + image + "@2x.png" + "> ");
            // res.sendFile(__dirname + "/respond.html");
            res.send();
        })
    });
});

const port = process.env.PORT || 3000;

app.listen(port, function () {
    console.log("Server is Running in port 3000");
})







// const query = "ahmedabad";
