$(document).ready(function() { 

    $("select").niceScroll();

  }

);